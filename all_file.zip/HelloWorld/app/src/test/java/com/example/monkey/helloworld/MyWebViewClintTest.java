package com.example.monkey.helloworld;

import static org.junit.Assert.*;

/**
 * Created by Monkey on 7/14/2016.
 */
public class MyWebViewClintTest {

}